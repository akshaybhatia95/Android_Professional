package com.mindorks.kotlinlecture4.model

data class ApiStudent(val firsName: String, val lastName: String, val averageMark: Int)