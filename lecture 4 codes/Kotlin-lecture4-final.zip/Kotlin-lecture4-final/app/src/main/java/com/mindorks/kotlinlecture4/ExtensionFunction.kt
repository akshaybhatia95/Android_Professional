package com.mindorks.kotlinlecture4

fun String.initial(): Char {
    return this[0]
}

fun Int.add(secondValue: Int): Int {
    return this + secondValue
}