package com.mindorks.kotlinlecture4.model

data class Student(val userName: String, val averageMark: Int)